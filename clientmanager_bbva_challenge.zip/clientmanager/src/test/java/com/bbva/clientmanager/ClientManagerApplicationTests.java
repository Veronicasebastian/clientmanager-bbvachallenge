package com.bbva.clientmanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
