package com.bbva.clientmanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClientManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClientManagerApplication.class, args);
	}

}
