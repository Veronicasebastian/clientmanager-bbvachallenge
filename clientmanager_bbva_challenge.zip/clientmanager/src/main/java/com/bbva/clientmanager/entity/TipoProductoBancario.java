package com.bbva.clientmanager.entity;

public enum TipoProductoBancario {
    CTACTE,
    CJAH,
    PREST,
    PZOF,
    CHEQ,
    TJCREDITO,
    TJDEBITO
}
