package com.bbva.clientmanager.exception;

public class ValorEnumInvalidoException extends RuntimeException {
    public ValorEnumInvalidoException(String message) {
        super(message);
    }
}
