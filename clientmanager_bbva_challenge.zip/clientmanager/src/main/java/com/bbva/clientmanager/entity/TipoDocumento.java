package com.bbva.clientmanager.entity;

public enum TipoDocumento {
    DNI,
    CI,
    PASAPORTE
}
